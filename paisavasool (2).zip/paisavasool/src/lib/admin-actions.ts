"use server";

import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { slugifyBasic } from "@/lib/utils";
import { OfferType } from "@prisma/client";

async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== "ADMIN") {
    redirect("/admin/login");
  }
  return session;
}

// ---------- Categories ----------

export async function createCategory(formData: FormData) {
  await requireAdmin();
  const name = String(formData.get("name") ?? "").trim();
  const icon = String(formData.get("icon") ?? "").trim();
  if (!name) return;

  await prisma.category.create({
    data: { name, slug: slugifyBasic(name), icon: icon || null },
  });
  revalidatePath("/admin/categories");
  redirect("/admin/categories");
}

export async function updateCategory(id: string, formData: FormData) {
  await requireAdmin();
  const name = String(formData.get("name") ?? "").trim();
  const icon = String(formData.get("icon") ?? "").trim();

  await prisma.category.update({
    where: { id },
    data: { name, icon: icon || null },
  });
  revalidatePath("/admin/categories");
  redirect("/admin/categories");
}

export async function deleteCategory(id: string) {
  await requireAdmin();
  await prisma.category.delete({ where: { id } });
  revalidatePath("/admin/categories");
}

// ---------- Stores ----------

export async function createStore(formData: FormData) {
  await requireAdmin();
  const name = String(formData.get("name") ?? "").trim();
  const websiteUrl = String(formData.get("websiteUrl") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();
  const featured = formData.get("featured") === "on";
  const categoryId = String(formData.get("categoryId") ?? "");
  if (!name || !websiteUrl) return;

  await prisma.store.create({
    data: {
      name,
      slug: slugifyBasic(name),
      websiteUrl,
      description: description || null,
      featured,
      categories: categoryId ? { connect: [{ id: categoryId }] } : undefined,
    },
  });
  revalidatePath("/admin/stores");
  redirect("/admin/stores");
}

export async function updateStore(id: string, formData: FormData) {
  await requireAdmin();
  const name = String(formData.get("name") ?? "").trim();
  const websiteUrl = String(formData.get("websiteUrl") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();
  const featured = formData.get("featured") === "on";

  await prisma.store.update({
    where: { id },
    data: { name, websiteUrl, description: description || null, featured },
  });
  revalidatePath("/admin/stores");
  redirect("/admin/stores");
}

export async function deleteStore(id: string) {
  await requireAdmin();
  await prisma.store.delete({ where: { id } });
  revalidatePath("/admin/stores");
}

// ---------- Offers (deals & coupons) ----------

export async function createOffer(formData: FormData) {
  await requireAdmin();
  const title = String(formData.get("title") ?? "").trim();
  const type = String(formData.get("type") ?? "DEAL") === "COUPON" ? OfferType.COUPON : OfferType.DEAL;
  const description = String(formData.get("description") ?? "").trim();
  const code = String(formData.get("code") ?? "").trim();
  const destinationUrl = String(formData.get("destinationUrl") ?? "").trim();
  const storeId = String(formData.get("storeId") ?? "");
  const categoryId = String(formData.get("categoryId") ?? "");
  const originalPrice = formData.get("originalPrice");
  const dealPrice = formData.get("dealPrice");
  const discountPct = formData.get("discountPct");
  const isLightning = formData.get("isLightning") === "on";

  if (!title || !destinationUrl || !storeId) return;

  await prisma.offer.create({
    data: {
      title,
      slug: `${slugifyBasic(title)}-${Date.now().toString(36)}`,
      type,
      description: description || null,
      code: code || null,
      destinationUrl,
      storeId,
      categoryId: categoryId || null,
      originalPrice: originalPrice ? Number(originalPrice) : null,
      dealPrice: dealPrice ? Number(dealPrice) : null,
      discountPct: discountPct ? Number(discountPct) : null,
      isLightning,
    },
  });
  revalidatePath("/admin/offers");
  revalidatePath("/");
  redirect("/admin/offers");
}

export async function updateOffer(id: string, formData: FormData) {
  await requireAdmin();
  const title = String(formData.get("title") ?? "").trim();
  const type = String(formData.get("type") ?? "DEAL") === "COUPON" ? OfferType.COUPON : OfferType.DEAL;
  const description = String(formData.get("description") ?? "").trim();
  const code = String(formData.get("code") ?? "").trim();
  const destinationUrl = String(formData.get("destinationUrl") ?? "").trim();
  const storeId = String(formData.get("storeId") ?? "");
  const categoryId = String(formData.get("categoryId") ?? "");
  const originalPrice = formData.get("originalPrice");
  const dealPrice = formData.get("dealPrice");
  const discountPct = formData.get("discountPct");
  const isLightning = formData.get("isLightning") === "on";
  const isActive = formData.get("isActive") === "on";

  await prisma.offer.update({
    where: { id },
    data: {
      title,
      type,
      description: description || null,
      code: code || null,
      destinationUrl,
      storeId,
      categoryId: categoryId || null,
      originalPrice: originalPrice ? Number(originalPrice) : null,
      dealPrice: dealPrice ? Number(dealPrice) : null,
      discountPct: discountPct ? Number(discountPct) : null,
      isLightning,
      isActive,
    },
  });
  revalidatePath("/admin/offers");
  revalidatePath("/");
  redirect("/admin/offers");
}

export async function deleteOffer(id: string) {
  await requireAdmin();
  await prisma.offer.delete({ where: { id } });
  revalidatePath("/admin/offers");
  revalidatePath("/");
}

export async function toggleOfferActive(id: string, isActive: boolean) {
  await requireAdmin();
  await prisma.offer.update({ where: { id }, data: { isActive } });
  revalidatePath("/admin/offers");
  revalidatePath("/");
}
