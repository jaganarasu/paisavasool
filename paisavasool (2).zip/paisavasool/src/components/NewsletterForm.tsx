"use client";

import { useState } from "react";

export default function NewsletterForm() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error();
      setStatus("done");
      setEmail("");
    } catch {
      setStatus("error");
    }
  }

  if (status === "done") {
    return <p className="text-sm text-mustard">You're on the list. First drop lands soon.</p>;
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input
        type="email"
        required
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="you@email.com"
        className="flex-1 min-w-0 rounded-full px-3 py-2 text-sm text-ink focus-ring"
      />
      <button
        type="submit"
        disabled={status === "loading"}
        className="bg-magenta text-paper text-sm font-medium px-4 py-2 rounded-full hover:bg-mustard hover:text-ink transition-colors focus-ring disabled:opacity-60"
      >
        {status === "loading" ? "Joining…" : "Join"}
      </button>
      {status === "error" && (
        <p className="text-xs text-mustard mt-1">Something went wrong — try again.</p>
      )}
    </form>
  );
}
