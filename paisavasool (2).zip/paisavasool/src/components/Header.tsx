"use client";

import Link from "next/link";
import { useSession, signOut } from "next-auth/react";

export default function Header() {
  const { data: session } = useSession();

  return (
    <header className="border-b-2 border-ink bg-paper sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-6">
        <Link href="/" className="flex items-center gap-2 focus-ring">
          <span className="font-display text-2xl tracking-tight text-ink">
            Paisa<span className="text-magenta">Vasool</span>
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-ink">
          <Link href="/stores" className="hover:text-magenta focus-ring">
            Stores
          </Link>
          <Link href="/categories" className="hover:text-magenta focus-ring">
            Categories
          </Link>
        </nav>

        <div className="flex items-center gap-4 text-sm font-medium">
          {session?.user ? (
            <>
              {session.user.role === "ADMIN" && (
                <Link href="/admin" className="hover:text-magenta focus-ring">
                  Admin
                </Link>
              )}
              <Link href="/account" className="hover:text-magenta focus-ring">
                My deals
              </Link>
              <button
                onClick={() => signOut({ callbackUrl: "/" })}
                className="text-muted hover:text-magenta focus-ring"
              >
                Sign out
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="hover:text-magenta focus-ring">
                Log in
              </Link>
              <Link
                href="/signup"
                className="bg-ink text-paper px-3 py-1.5 rounded-full hover:bg-magenta transition-colors focus-ring"
              >
                Sign up
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
