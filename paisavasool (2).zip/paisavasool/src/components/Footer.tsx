import Link from "next/link";
import NewsletterForm from "@/components/NewsletterForm";

export default function Footer() {
  return (
    <footer className="border-t-2 border-ink mt-20 bg-ink text-paper">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 grid gap-10 md:grid-cols-3">
        <div>
          <span className="font-display text-xl">
            Paisa<span className="text-mustard">Vasool</span>
          </span>
          <p className="mt-3 text-sm text-paper/70 max-w-xs">
            Hand-checked coupons and deals from stores across India. We remove
            codes the moment they stop working.
          </p>
        </div>

        <div className="text-sm">
          <p className="uppercase tracking-wide text-paper/50 mb-3">Browse</p>
          <ul className="space-y-2">
            <li>
              <Link href="/stores" className="hover:text-mustard">
                All stores
              </Link>
            </li>
            <li>
              <Link href="/categories" className="hover:text-mustard">
                Categories
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <p className="text-sm uppercase tracking-wide text-paper/50 mb-3">
            Get the weekly drop
          </p>
          <NewsletterForm />
        </div>
      </div>
      <div className="text-center text-xs text-paper/40 pb-6">
        © {new Date().getFullYear()} PaisaVasool. All offers belong to their respective stores.
      </div>
    </footer>
  );
}
