"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { formatINR } from "@/lib/utils";

type OfferCardProps = {
  id: string;
  title: string;
  storeName: string;
  type: "COUPON" | "DEAL";
  code?: string | null;
  discountPct?: number | null;
  originalPrice?: number | null;
  dealPrice?: number | null;
  isLightning?: boolean;
};

export default function OfferCard(offer: OfferCardProps) {
  const { data: session } = useSession();
  const [copied, setCopied] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  async function handleCopy() {
    if (!offer.code) return;
    await navigator.clipboard.writeText(offer.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  async function handleSave() {
    if (!session?.user || saving) return;
    setSaving(true);
    try {
      const res = await fetch("/api/saved-offers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ offerId: offer.id }),
      });
      const data = await res.json();
      setSaved(Boolean(data.saved));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="tag-card border-2 border-ink bg-white p-4 flex flex-col gap-3 h-full">
      <div className="flex items-start justify-between gap-2">
        <span className="text-xs font-medium text-muted">{offer.storeName}</span>
        <div className="flex items-center gap-2">
          {offer.isLightning && (
            <span className="text-xs font-semibold text-magenta">⚡ Lightning</span>
          )}
          {session?.user && (
            <button
              onClick={handleSave}
              aria-label={saved ? "Unsave deal" : "Save deal"}
              className="text-sm focus-ring"
              title={saved ? "Saved" : "Save"}
            >
              {saved ? "★" : "☆"}
            </button>
          )}
        </div>
      </div>

      <h3 className="font-display text-base leading-snug text-ink line-clamp-3">
        {offer.title}
      </h3>

      <div className="flex items-center gap-2 mt-auto">
        {offer.discountPct ? (
          <span className="bg-mustard text-ink text-sm font-bold px-2 py-0.5 rounded">
            {offer.discountPct}% OFF
          </span>
        ) : null}
        {offer.originalPrice && offer.dealPrice ? (
          <span className="text-xs text-muted">
            <span className="line-through">{formatINR(offer.originalPrice)}</span>{" "}
            <span className="text-teal font-semibold">{formatINR(offer.dealPrice)}</span>
          </span>
        ) : null}
      </div>

      {offer.type === "COUPON" && offer.code ? (
        <button
          onClick={handleCopy}
          className="border-2 border-dashed border-ink rounded-full px-3 py-2 text-sm font-semibold tracking-wide text-center hover:bg-paper focus-ring"
        >
          {copied ? "Copied!" : `${offer.code} · Copy code`}
        </button>
      ) : (
        <a
          href={`/go/${offer.id}`}
          target="_blank"
          rel="noopener noreferrer nofollow sponsored"
          className="bg-ink text-paper text-sm font-semibold text-center rounded-full px-3 py-2 hover:bg-magenta transition-colors focus-ring"
        >
          Grab deal
        </a>
      )}

      {offer.type === "COUPON" && offer.code ? (
        <a
          href={`/go/${offer.id}`}
          target="_blank"
          rel="noopener noreferrer nofollow sponsored"
          className="text-xs text-center text-muted hover:text-magenta focus-ring"
        >
          Use at store →
        </a>
      ) : null}
    </div>
  );
}
