import Link from "next/link";

export default function StoreCard({
  name,
  slug,
  description,
  offerCount,
}: {
  name: string;
  slug: string;
  description?: string | null;
  offerCount: number;
}) {
  return (
    <Link
      href={`/stores/${slug}`}
      className="border-2 border-ink rounded-2xl p-5 bg-white hover:-translate-y-0.5 hover:shadow-[4px_4px_0_#14122B] transition-all focus-ring flex flex-col gap-2"
    >
      <span className="font-display text-lg text-ink">{name}</span>
      {description && <p className="text-sm text-muted line-clamp-2">{description}</p>}
      <span className="text-xs font-semibold text-teal mt-auto">
        {offerCount} live offer{offerCount === 1 ? "" : "s"}
      </span>
    </Link>
  );
}
