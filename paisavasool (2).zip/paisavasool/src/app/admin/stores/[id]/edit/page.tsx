import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { updateStore } from "@/lib/admin-actions";

export default async function EditStorePage({ params }: { params: { id: string } }) {
  const store = await prisma.store.findUnique({ where: { id: params.id } });
  if (!store) notFound();

  const updateWithId = updateStore.bind(null, store.id);

  return (
    <div className="max-w-sm">
      <h1 className="font-display text-2xl text-ink mb-6">Edit store</h1>
      <form action={updateWithId} className="flex flex-col gap-3">
        <input
          name="name"
          required
          defaultValue={store.name}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        />
        <input
          name="websiteUrl"
          required
          type="url"
          defaultValue={store.websiteUrl}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        />
        <textarea
          name="description"
          defaultValue={store.description ?? ""}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        />
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="featured" defaultChecked={store.featured} /> Feature on
          homepage
        </label>
        <button className="bg-ink text-paper font-semibold rounded-full py-2 hover:bg-magenta transition-colors focus-ring">
          Save changes
        </button>
      </form>
    </div>
  );
}
