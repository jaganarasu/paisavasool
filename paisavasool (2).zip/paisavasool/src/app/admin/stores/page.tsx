import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { createStore, deleteStore } from "@/lib/admin-actions";

export default async function AdminStoresPage() {
  const [stores, categories] = await Promise.all([
    prisma.store.findMany({
      orderBy: { name: "asc" },
      include: { _count: { select: { offers: true } } },
    }),
    prisma.category.findMany({ orderBy: { name: "asc" } }),
  ]);

  return (
    <div className="grid gap-8">
      <div>
        <h1 className="font-display text-2xl text-ink mb-4">Stores</h1>
        <table className="w-full text-sm border-2 border-ink bg-white rounded-xl overflow-hidden">
          <thead className="bg-paper text-left">
            <tr>
              <th className="p-3">Name</th>
              <th className="p-3">Offers</th>
              <th className="p-3">Featured</th>
              <th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {stores.map((s) => (
              <tr key={s.id} className="border-t border-ink/20">
                <td className="p-3">{s.name}</td>
                <td className="p-3">{s._count.offers}</td>
                <td className="p-3">{s.featured ? "★" : ""}</td>
                <td className="p-3 flex gap-3">
                  <Link href={`/admin/stores/${s.id}/edit`} className="text-magenta hover:underline">
                    Edit
                  </Link>
                  <form action={deleteStore.bind(null, s.id)}>
                    <button className="text-muted hover:text-magenta">Delete</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {stores.length === 0 && <p className="text-muted text-sm mt-3">No stores yet.</p>}
      </div>

      <div className="max-w-sm">
        <h2 className="font-display text-lg text-ink mb-3">Add store</h2>
        <form action={createStore} className="flex flex-col gap-3">
          <input
            name="name"
            required
            placeholder="Store name"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <input
            name="websiteUrl"
            required
            type="url"
            placeholder="https://store-website.com"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <textarea
            name="description"
            placeholder="Short description"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <select name="categoryId" className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring">
            <option value="">No category</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="featured" /> Feature on homepage
          </label>
          <button className="bg-ink text-paper font-semibold rounded-full py-2 hover:bg-magenta transition-colors focus-ring">
            Add store
          </button>
        </form>
      </div>
    </div>
  );
}
