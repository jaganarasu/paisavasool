import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const links = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/offers", label: "Deals & Coupons" },
  { href: "/admin/stores", label: "Stores" },
  { href: "/admin/categories", label: "Categories" },
  { href: "/admin/stats", label: "Click stats" },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);

  // The login page renders inside this layout too, without the shell.
  if (!session?.user || session.user.role !== "ADMIN") {
    return <div className="bg-paper min-h-screen">{children}</div>;
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 grid grid-cols-1 md:grid-cols-[180px_1fr] gap-8">
      <aside className="flex md:flex-col gap-2 overflow-x-auto">
        {links.map((l) => (
          <Link
            key={l.href}
            href={l.href}
            className="text-sm font-medium text-ink px-3 py-2 rounded-lg hover:bg-mustard/30 whitespace-nowrap focus-ring"
          >
            {l.label}
          </Link>
        ))}
      </aside>
      <div>{children}</div>
    </div>
  );
}
