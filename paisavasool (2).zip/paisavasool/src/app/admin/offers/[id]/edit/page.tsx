import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { updateOffer } from "@/lib/admin-actions";

export default async function EditOfferPage({ params }: { params: { id: string } }) {
  const [offer, stores, categories] = await Promise.all([
    prisma.offer.findUnique({ where: { id: params.id } }),
    prisma.store.findMany({ orderBy: { name: "asc" } }),
    prisma.category.findMany({ orderBy: { name: "asc" } }),
  ]);
  if (!offer) notFound();

  const updateWithId = updateOffer.bind(null, offer.id);

  return (
    <div className="max-w-md">
      <h1 className="font-display text-2xl text-ink mb-6">Edit offer</h1>
      <form action={updateWithId} className="flex flex-col gap-3">
        <input
          name="title"
          required
          defaultValue={offer.title}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        />
        <select
          name="type"
          defaultValue={offer.type}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        >
          <option value="DEAL">Deal</option>
          <option value="COUPON">Coupon</option>
        </select>
        <textarea
          name="description"
          defaultValue={offer.description ?? ""}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        />
        <input
          name="code"
          defaultValue={offer.code ?? ""}
          placeholder="Coupon code"
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        />
        <input
          name="destinationUrl"
          required
          type="url"
          defaultValue={offer.destinationUrl}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        />
        <select
          name="storeId"
          required
          defaultValue={offer.storeId}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        >
          {stores.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
        <select
          name="categoryId"
          defaultValue={offer.categoryId ?? ""}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        >
          <option value="">No category</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <div className="grid grid-cols-3 gap-2">
          <input
            name="originalPrice"
            type="number"
            defaultValue={offer.originalPrice ?? ""}
            placeholder="MRP ₹"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <input
            name="dealPrice"
            type="number"
            defaultValue={offer.dealPrice ?? ""}
            placeholder="Deal ₹"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <input
            name="discountPct"
            type="number"
            defaultValue={offer.discountPct ?? ""}
            placeholder="% off"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="isLightning" defaultChecked={offer.isLightning} /> Lightning
          deal
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="isActive" defaultChecked={offer.isActive} /> Active
        </label>
        <button className="bg-ink text-paper font-semibold rounded-full py-2 hover:bg-magenta transition-colors focus-ring">
          Save changes
        </button>
      </form>
    </div>
  );
}
