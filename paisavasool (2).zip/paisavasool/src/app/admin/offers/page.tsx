import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { createOffer, deleteOffer, toggleOfferActive } from "@/lib/admin-actions";

export default async function AdminOffersPage() {
  const [offers, stores, categories] = await Promise.all([
    prisma.offer.findMany({
      orderBy: { createdAt: "desc" },
      include: { store: true, _count: { select: { clicks: true } } },
    }),
    prisma.store.findMany({ orderBy: { name: "asc" } }),
    prisma.category.findMany({ orderBy: { name: "asc" } }),
  ]);

  return (
    <div className="grid gap-8">
      <div>
        <h1 className="font-display text-2xl text-ink mb-4">Deals & Coupons</h1>
        <table className="w-full text-sm border-2 border-ink bg-white rounded-xl overflow-hidden">
          <thead className="bg-paper text-left">
            <tr>
              <th className="p-3">Title</th>
              <th className="p-3">Store</th>
              <th className="p-3">Type</th>
              <th className="p-3">Clicks</th>
              <th className="p-3">Active</th>
              <th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {offers.map((o) => (
              <tr key={o.id} className="border-t border-ink/20">
                <td className="p-3 max-w-xs truncate">{o.title}</td>
                <td className="p-3">{o.store.name}</td>
                <td className="p-3">{o.type}</td>
                <td className="p-3">{o._count.clicks}</td>
                <td className="p-3">
                  <form action={toggleOfferActive.bind(null, o.id, !o.isActive)}>
                    <button
                      className={`text-xs font-semibold px-2 py-1 rounded-full ${
                        o.isActive ? "bg-teal text-white" : "bg-muted/30 text-muted"
                      }`}
                    >
                      {o.isActive ? "Live" : "Paused"}
                    </button>
                  </form>
                </td>
                <td className="p-3 flex gap-3">
                  <Link href={`/admin/offers/${o.id}/edit`} className="text-magenta hover:underline">
                    Edit
                  </Link>
                  <form action={deleteOffer.bind(null, o.id)}>
                    <button className="text-muted hover:text-magenta">Delete</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {offers.length === 0 && <p className="text-muted text-sm mt-3">No offers yet.</p>}
      </div>

      <div className="max-w-md">
        <h2 className="font-display text-lg text-ink mb-3">Add deal or coupon</h2>
        <form action={createOffer} className="flex flex-col gap-3">
          <input
            name="title"
            required
            placeholder="Title"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <select name="type" className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring">
            <option value="DEAL">Deal</option>
            <option value="COUPON">Coupon</option>
          </select>
          <textarea
            name="description"
            placeholder="Description"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <input
            name="code"
            placeholder="Coupon code (leave blank for plain deals)"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <input
            name="destinationUrl"
            required
            type="url"
            placeholder="https://store.com/product-or-offer"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <select name="storeId" required className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring">
            <option value="">Select store</option>
            {stores.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <select name="categoryId" className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring">
            <option value="">No category</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
          <div className="grid grid-cols-3 gap-2">
            <input
              name="originalPrice"
              type="number"
              placeholder="MRP ₹"
              className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
            />
            <input
              name="dealPrice"
              type="number"
              placeholder="Deal ₹"
              className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
            />
            <input
              name="discountPct"
              type="number"
              placeholder="% off"
              className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
            />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="isLightning" /> Mark as lightning deal
          </label>
          <button className="bg-ink text-paper font-semibold rounded-full py-2 hover:bg-magenta transition-colors focus-ring">
            Add offer
          </button>
        </form>
      </div>
    </div>
  );
}
