import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { updateCategory } from "@/lib/admin-actions";

export default async function EditCategoryPage({ params }: { params: { id: string } }) {
  const category = await prisma.category.findUnique({ where: { id: params.id } });
  if (!category) notFound();

  const updateWithId = updateCategory.bind(null, category.id);

  return (
    <div className="max-w-sm">
      <h1 className="font-display text-2xl text-ink mb-6">Edit category</h1>
      <form action={updateWithId} className="flex flex-col gap-3">
        <input
          name="name"
          required
          defaultValue={category.name}
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        />
        <input
          name="icon"
          defaultValue={category.icon ?? ""}
          placeholder="Icon (emoji)"
          className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
        />
        <button className="bg-ink text-paper font-semibold rounded-full py-2 hover:bg-magenta transition-colors focus-ring">
          Save changes
        </button>
      </form>
    </div>
  );
}
