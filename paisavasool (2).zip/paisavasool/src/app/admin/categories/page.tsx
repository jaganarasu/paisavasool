import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { createCategory, deleteCategory } from "@/lib/admin-actions";

export default async function AdminCategoriesPage() {
  const categories = await prisma.category.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { offers: true, stores: true } } },
  });

  return (
    <div className="grid gap-8">
      <div>
        <h1 className="font-display text-2xl text-ink mb-4">Categories</h1>
        <table className="w-full text-sm border-2 border-ink bg-white rounded-xl overflow-hidden">
          <thead className="bg-paper text-left">
            <tr>
              <th className="p-3">Name</th>
              <th className="p-3">Offers</th>
              <th className="p-3">Stores</th>
              <th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id} className="border-t border-ink/20">
                <td className="p-3">
                  {c.icon} {c.name}
                </td>
                <td className="p-3">{c._count.offers}</td>
                <td className="p-3">{c._count.stores}</td>
                <td className="p-3 flex gap-3">
                  <Link href={`/admin/categories/${c.id}/edit`} className="text-magenta hover:underline">
                    Edit
                  </Link>
                  <form action={deleteCategory.bind(null, c.id)}>
                    <button className="text-muted hover:text-magenta">Delete</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {categories.length === 0 && <p className="text-muted text-sm mt-3">No categories yet.</p>}
      </div>

      <div className="max-w-sm">
        <h2 className="font-display text-lg text-ink mb-3">Add category</h2>
        <form action={createCategory} className="flex flex-col gap-3">
          <input
            name="name"
            required
            placeholder="Name"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <input
            name="icon"
            placeholder="Icon (emoji, optional)"
            className="border-2 border-ink rounded-lg px-3 py-2 text-sm focus-ring"
          />
          <button className="bg-ink text-paper font-semibold rounded-full py-2 hover:bg-magenta transition-colors focus-ring">
            Add category
          </button>
        </form>
      </div>
    </div>
  );
}
