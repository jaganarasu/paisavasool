import { prisma } from "@/lib/prisma";

export default async function AdminStatsPage() {
  const since7 = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const since30 = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  const offers = await prisma.offer.findMany({
    include: {
      store: true,
      _count: {
        select: {
          clicks: true,
        },
      },
    },
    orderBy: { clicks: { _count: "desc" } },
    take: 50,
  });

  const [clicks7, clicks30] = await Promise.all([
    prisma.click.count({ where: { createdAt: { gte: since7 } } }),
    prisma.click.count({ where: { createdAt: { gte: since30 } } }),
  ]);

  return (
    <div>
      <h1 className="font-display text-2xl text-ink mb-4">Click stats</h1>
      <div className="flex gap-4 mb-6">
        <div className="border-2 border-ink rounded-xl p-4 bg-white">
          <p className="text-2xl font-display">{clicks7}</p>
          <p className="text-xs text-muted">Clicks, last 7 days</p>
        </div>
        <div className="border-2 border-ink rounded-xl p-4 bg-white">
          <p className="text-2xl font-display">{clicks30}</p>
          <p className="text-xs text-muted">Clicks, last 30 days</p>
        </div>
      </div>

      <table className="w-full text-sm border-2 border-ink bg-white rounded-xl overflow-hidden">
        <thead className="bg-paper text-left">
          <tr>
            <th className="p-3">Offer</th>
            <th className="p-3">Store</th>
            <th className="p-3">Total clicks</th>
          </tr>
        </thead>
        <tbody>
          {offers.map((o) => (
            <tr key={o.id} className="border-t border-ink/20">
              <td className="p-3 max-w-xs truncate">{o.title}</td>
              <td className="p-3">{o.store.name}</td>
              <td className="p-3 font-semibold">{o._count.clicks}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
