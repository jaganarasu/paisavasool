import { prisma } from "@/lib/prisma";

export default async function AdminDashboard() {
  const [storeCount, offerCount, activeOfferCount, clickCount, subscriberCount, userCount] =
    await Promise.all([
      prisma.store.count(),
      prisma.offer.count(),
      prisma.offer.count({ where: { isActive: true } }),
      prisma.click.count(),
      prisma.newsletterSubscriber.count(),
      prisma.user.count({ where: { role: "USER" } }),
    ]);

  const stats = [
    { label: "Stores", value: storeCount },
    { label: "Live offers", value: activeOfferCount },
    { label: "Total offers", value: offerCount },
    { label: "Total clicks", value: clickCount },
    { label: "Newsletter subscribers", value: subscriberCount },
    { label: "Shopper accounts", value: userCount },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl text-ink mb-6">Dashboard</h1>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="border-2 border-ink rounded-xl p-4 bg-white">
            <p className="text-2xl font-display text-ink">{s.value}</p>
            <p className="text-xs text-muted">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
