import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return NextResponse.json({ error: "Log in to save deals." }, { status: 401 });
  }

  const { offerId } = await req.json().catch(() => ({ offerId: null }));
  if (!offerId) return NextResponse.json({ error: "Missing offerId" }, { status: 400 });

  const existing = await prisma.savedOffer.findUnique({
    where: { userId_offerId: { userId: session.user.id, offerId } },
  });

  if (existing) {
    await prisma.savedOffer.delete({ where: { id: existing.id } });
    return NextResponse.json({ saved: false });
  }

  await prisma.savedOffer.create({ data: { userId: session.user.id, offerId } });
  return NextResponse.json({ saved: true });
}
