import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request, { params }: { params: { id: string } }) {
  const offer = await prisma.offer.findUnique({ where: { id: params.id } });

  if (!offer || !offer.isActive) {
    return NextResponse.redirect(new URL("/", req.url));
  }

  // Fire-and-forget click log; don't block the redirect on it.
  prisma.click
    .create({
      data: {
        offerId: offer.id,
        userAgent: req.headers.get("user-agent") ?? undefined,
        referer: req.headers.get("referer") ?? undefined,
      },
    })
    .catch(() => {
      /* tracking failures should never block a redirect */
    });

  return NextResponse.redirect(offer.destinationUrl, { status: 302 });
}
