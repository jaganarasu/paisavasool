import Link from "next/link";
import { prisma } from "@/lib/prisma";
import OfferCard from "@/components/OfferCard";
import StoreCard from "@/components/StoreCard";

export const revalidate = 60;

export default async function HomePage() {
  const [hotOffers, categories, featuredStores] = await Promise.all([
    prisma.offer.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
      take: 12,
      include: { store: true },
    }),
    prisma.category.findMany({ take: 8 }),
    prisma.store.findMany({
      where: { featured: true },
      take: 6,
      include: { _count: { select: { offers: { where: { isActive: true } } } } },
    }),
  ]);

  const tickerItems = hotOffers.slice(0, 8);

  return (
    <div>
      {/* Hero: bazaar-ticker of live discount percentages */}
      <section className="border-b-2 border-ink bg-ink text-paper overflow-hidden py-3">
        <div className="marquee-track">
          {[...tickerItems, ...tickerItems].map((o, i) => (
            <span key={i} className="flex items-center gap-2 px-6 text-sm font-display whitespace-nowrap">
              <span className="text-mustard">{o.discountPct ? `${o.discountPct}% OFF` : "NEW"}</span>
              <span className="text-paper/60">·</span>
              <span>{o.store.name}</span>
            </span>
          ))}
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-14 pb-10">
        <h1 className="font-display text-4xl sm:text-5xl leading-[1.05] text-ink max-w-2xl">
          Every coupon here has actually been checked.
        </h1>
        <p className="mt-4 text-muted max-w-lg">
          No expired codes padding out a list. We test what we publish, and pull
          it the moment it stops working.
        </p>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-16">
        <div className="flex items-baseline justify-between mb-5">
          <h2 className="font-display text-2xl text-ink">Hot right now</h2>
          <Link href="/stores" className="text-sm font-medium text-magenta hover:underline">
            Browse all stores →
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {hotOffers.map((offer) => (
            <OfferCard
              key={offer.id}
              id={offer.id}
              title={offer.title}
              storeName={offer.store.name}
              type={offer.type}
              code={offer.code}
              discountPct={offer.discountPct}
              originalPrice={offer.originalPrice}
              dealPrice={offer.dealPrice}
              isLightning={offer.isLightning}
            />
          ))}
        </div>
        {hotOffers.length === 0 && (
          <p className="text-muted text-sm">
            No live offers yet — add some from the admin dashboard.
          </p>
        )}
      </section>

      <section className="bg-white border-y-2 border-ink py-14">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <h2 className="font-display text-2xl text-ink mb-6">Shop by category</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {categories.map((c) => (
              <Link
                key={c.id}
                href={`/categories/${c.slug}`}
                className="border-2 border-ink rounded-xl p-4 text-center hover:bg-mustard/30 transition-colors focus-ring"
              >
                <span className="text-2xl">{c.icon}</span>
                <p className="mt-2 text-sm font-semibold text-ink">{c.name}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <h2 className="font-display text-2xl text-ink mb-6">Featured stores</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {featuredStores.map((s) => (
            <StoreCard
              key={s.id}
              name={s.name}
              slug={s.slug}
              description={s.description}
              offerCount={s._count.offers}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
