import Link from "next/link";

export default function NotFound() {
  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center">
      <h1 className="font-display text-3xl text-ink mb-3">That deal expired.</h1>
      <p className="text-muted mb-6">Or the page just doesn't exist. Either way, plenty more on the homepage.</p>
      <Link
        href="/"
        className="inline-block bg-ink text-paper font-semibold rounded-full px-5 py-2 hover:bg-magenta transition-colors focus-ring"
      >
        Back to deals
      </Link>
    </div>
  );
}
