import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import OfferCard from "@/components/OfferCard";

export const revalidate = 60;

export default async function StoreDetailPage({ params }: { params: { slug: string } }) {
  const store = await prisma.store.findUnique({
    where: { slug: params.slug },
    include: {
      offers: { where: { isActive: true }, orderBy: { createdAt: "desc" } },
    },
  });

  if (!store) notFound();

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
      <div className="mb-10">
        <h1 className="font-display text-3xl text-ink">{store.name}</h1>
        {store.description && <p className="text-muted mt-2 max-w-xl">{store.description}</p>}
        <a
          href={store.websiteUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block mt-3 text-sm font-medium text-magenta hover:underline"
        >
          Visit {store.name} →
        </a>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {store.offers.map((offer) => (
          <OfferCard
            key={offer.id}
            id={offer.id}
            title={offer.title}
            storeName={store.name}
            type={offer.type}
            code={offer.code}
            discountPct={offer.discountPct}
            originalPrice={offer.originalPrice}
            dealPrice={offer.dealPrice}
            isLightning={offer.isLightning}
          />
        ))}
      </div>
      {store.offers.length === 0 && (
        <p className="text-muted text-sm">No live offers for {store.name} right now.</p>
      )}
    </div>
  );
}
