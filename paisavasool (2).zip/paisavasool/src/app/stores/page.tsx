import { prisma } from "@/lib/prisma";
import StoreCard from "@/components/StoreCard";

export const revalidate = 60;

export default async function StoresPage() {
  const stores = await prisma.store.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { offers: { where: { isActive: true } } } } },
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
      <h1 className="font-display text-3xl text-ink mb-8">All stores</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {stores.map((s) => (
          <StoreCard
            key={s.id}
            name={s.name}
            slug={s.slug}
            description={s.description}
            offerCount={s._count.offers}
          />
        ))}
      </div>
      {stores.length === 0 && <p className="text-muted text-sm">No stores yet.</p>}
    </div>
  );
}
