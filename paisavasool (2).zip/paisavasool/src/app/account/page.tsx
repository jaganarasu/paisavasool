import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import OfferCard from "@/components/OfferCard";

export default async function AccountPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");

  const saved = await prisma.savedOffer.findMany({
    where: { userId: session.user.id },
    include: { offer: { include: { store: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
      <h1 className="font-display text-3xl text-ink mb-2">My deals</h1>
      <p className="text-muted mb-8">Signed in as {session.user.email}</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {saved.map(({ offer }) => (
          <OfferCard
            key={offer.id}
            id={offer.id}
            title={offer.title}
            storeName={offer.store.name}
            type={offer.type}
            code={offer.code}
            discountPct={offer.discountPct}
            originalPrice={offer.originalPrice}
            dealPrice={offer.dealPrice}
            isLightning={offer.isLightning}
          />
        ))}
      </div>
      {saved.length === 0 && (
        <p className="text-muted text-sm">
          Nothing saved yet — browse deals and tap save to keep them here.
        </p>
      )}
    </div>
  );
}
