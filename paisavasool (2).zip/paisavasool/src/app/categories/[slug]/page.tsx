import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import OfferCard from "@/components/OfferCard";

export const revalidate = 60;

export default async function CategoryDetailPage({ params }: { params: { slug: string } }) {
  const category = await prisma.category.findUnique({
    where: { slug: params.slug },
    include: {
      offers: {
        where: { isActive: true },
        orderBy: { createdAt: "desc" },
        include: { store: true },
      },
    },
  });

  if (!category) notFound();

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
      <h1 className="font-display text-3xl text-ink mb-8">
        {category.icon} {category.name}
      </h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {category.offers.map((offer) => (
          <OfferCard
            key={offer.id}
            id={offer.id}
            title={offer.title}
            storeName={offer.store.name}
            type={offer.type}
            code={offer.code}
            discountPct={offer.discountPct}
            originalPrice={offer.originalPrice}
            dealPrice={offer.dealPrice}
            isLightning={offer.isLightning}
          />
        ))}
      </div>
      {category.offers.length === 0 && (
        <p className="text-muted text-sm">No live offers in this category yet.</p>
      )}
    </div>
  );
}
