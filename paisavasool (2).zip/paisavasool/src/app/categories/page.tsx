import Link from "next/link";
import { prisma } from "@/lib/prisma";

export const revalidate = 60;

export default async function CategoriesPage() {
  const categories = await prisma.category.findMany({
    orderBy: { name: "asc" },
    include: { _count: { select: { offers: { where: { isActive: true } } } } },
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14">
      <h1 className="font-display text-3xl text-ink mb-8">Categories</h1>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {categories.map((c) => (
          <Link
            key={c.id}
            href={`/categories/${c.slug}`}
            className="border-2 border-ink rounded-xl p-5 text-center hover:bg-mustard/30 transition-colors focus-ring"
          >
            <span className="text-3xl">{c.icon}</span>
            <p className="mt-2 text-sm font-semibold text-ink">{c.name}</p>
            <p className="text-xs text-muted">{c._count.offers} offers</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
