import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token;
    const isAdminRoute = req.nextUrl.pathname.startsWith("/admin");
    const isAdminLogin = req.nextUrl.pathname === "/admin/login";

    if (isAdminRoute && !isAdminLogin) {
      if (!token || token.role !== "ADMIN") {
        const loginUrl = new URL("/admin/login", req.url);
        return NextResponse.redirect(loginUrl);
      }
    }
    return NextResponse.next();
  },
  {
    callbacks: {
      // Always run the middleware function above; it does its own checks.
      authorized: () => true,
    },
  }
);

export const config = {
  matcher: ["/admin/:path*"],
};
