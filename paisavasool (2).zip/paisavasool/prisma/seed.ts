import { PrismaClient, OfferType, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const adminEmail = process.env.SEED_ADMIN_EMAIL || "admin@paisavasool.in";
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || "ChangeMe123!";

  const passwordHash = await bcrypt.hash(adminPassword, 10);
  await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      name: "Admin",
      passwordHash,
      role: Role.ADMIN,
    },
  });
  console.log(`Admin user ready: ${adminEmail} / ${adminPassword}`);

  const categories = [
    { name: "Electronics", slug: "electronics", icon: "📱" },
    { name: "Fashion", slug: "fashion", icon: "👕" },
    { name: "Home & Kitchen", slug: "home-kitchen", icon: "🏠" },
    { name: "Beauty", slug: "beauty", icon: "💄" },
    { name: "Food Delivery", slug: "food-delivery", icon: "🍔" },
  ];
  for (const c of categories) {
    await prisma.category.upsert({ where: { slug: c.slug }, update: {}, create: c });
  }
  const [electronics, fashion, home] = await Promise.all([
    prisma.category.findUnique({ where: { slug: "electronics" } }),
    prisma.category.findUnique({ where: { slug: "fashion" } }),
    prisma.category.findUnique({ where: { slug: "home-kitchen" } }),
  ]);

  const stores = [
    {
      name: "TechBazaar",
      slug: "techbazaar",
      websiteUrl: "https://example.com/techbazaar",
      description: "Gadgets, phones and accessories at bazaar prices.",
      featured: true,
      categories: { connect: [{ id: electronics!.id }] },
    },
    {
      name: "StyleMandi",
      slug: "stylemandi",
      websiteUrl: "https://example.com/stylemandi",
      description: "Fashion for every season, every budget.",
      featured: true,
      categories: { connect: [{ id: fashion!.id }] },
    },
    {
      name: "GharSaaz",
      slug: "gharsaaz",
      websiteUrl: "https://example.com/gharsaaz",
      description: "Everything to build a better home.",
      featured: false,
      categories: { connect: [{ id: home!.id }] },
    },
  ];

  for (const s of stores) {
    await prisma.store.upsert({ where: { slug: s.slug }, update: {}, create: s });
  }
  const techbazaar = await prisma.store.findUnique({ where: { slug: "techbazaar" } });
  const stylemandi = await prisma.store.findUnique({ where: { slug: "stylemandi" } });

  const offers = [
    {
      title: "Flat 40% off wireless earbuds",
      slug: "techbazaar-earbuds-40",
      type: OfferType.DEAL,
      description: "Top-rated wireless earbuds with ANC, flat 40% off this week.",
      originalPrice: 3999,
      dealPrice: 2399,
      discountPct: 40,
      destinationUrl: "https://example.com/techbazaar/earbuds",
      storeId: techbazaar!.id,
      categoryId: electronics!.id,
      isLightning: true,
    },
    {
      title: "Extra ₹500 off orders above ₹2999",
      slug: "techbazaar-code-500off",
      type: OfferType.COUPON,
      description: "Use code at checkout for an extra ₹500 off.",
      code: "TECH500",
      destinationUrl: "https://example.com/techbazaar",
      storeId: techbazaar!.id,
      categoryId: electronics!.id,
    },
    {
      title: "Buy 2 Get 1 Free on t-shirts",
      slug: "stylemandi-b2g1",
      type: OfferType.DEAL,
      description: "Mix and match across the summer collection.",
      discountPct: 33,
      destinationUrl: "https://example.com/stylemandi/tshirts",
      storeId: stylemandi!.id,
      categoryId: fashion!.id,
    },
  ];

  for (const o of offers) {
    await prisma.offer.upsert({ where: { slug: o.slug }, update: {}, create: o });
  }

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
